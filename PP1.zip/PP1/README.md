# Raúl H. Segarra Correa 840-20-4242 raul.segarra@upr.edu
# Diego A. Rosado Tavarez 840-20-6741 diego.rosado4@upr.edu